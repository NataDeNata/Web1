const noteContainers = document.querySelector('.note-containers');
const createNoteButton = document.querySelector('.btn');
let noteCount = 0;

createNoteButton.addEventListener('click', function() {
    
//creates note container max of 6
    if(noteCount < 6){
        
  const noteContainer = document.createElement('div');
  noteContainer.className = 'note-container';

  //title area for user
  const titleInput = document.createElement('input');
  titleInput.type = 'text';
  titleInput.placeholder = 'Title';
  titleInput.className = 'title-input';

  //note area for user
  const noteTextArea = document.createElement('div');
  noteTextArea.className = 'note-textarea';
  noteTextArea.contentEditable = 'true';
  noteTextArea.style.backgroundColor = 'white';
  noteTextArea.placeholder = 'Write your note here...';
 



  //dropdown with save and delete icons
  const dropdownButton = document.createElement('button');
  dropdownButton.className = 'dropdown-button';
  const dropdownIcon = document.createElement('img');
  dropdownIcon.src = 'dropdown.png';
  dropdownIcon.alt = 'Dropdown';
  dropdownButton.appendChild(dropdownIcon);

  const dropdownContent = document.createElement('div');
  dropdownContent.className = 'dropdown-content';
  dropdownContent.style.display = 'none';

  //delete icon
  const trashButton = document.createElement('button');
  trashButton.className = 'dropdown-item';
  const trashIcon = document.createElement('img');
  trashIcon.src = 'trash.png';
  trashIcon.alt = 'Trash';
  trashButton.appendChild(trashIcon);

  //save icon
  const saveButton = document.createElement('button');
  saveButton.className = 'dropdown-item';
  const saveIcon = document.createElement('img');
  saveIcon.className = 'save-icon';
  saveIcon.src = 'save.png';
  saveIcon.alt = 'Save';
  saveButton.appendChild(saveIcon);

  //attach image icon
  const imgAttachButton = document.createElement('button');
  imgAttachButton.className = 'dropdown-item';
  const imgAttachIcon = document.createElement('img');
  imgAttachIcon.className = 'img-attach-icon';
  imgAttachIcon.src = 'imgAtch.png';
  imgAttachIcon.alt = 'Image';
  imgAttachButton.appendChild(imgAttachIcon);

  //append all icons to dropdown content
  dropdownContent.appendChild(trashButton);
  dropdownContent.appendChild(saveButton);
  dropdownContent.appendChild(imgAttachButton);


  //dropdown functions when clicked, replaces dropdown to dropdown2 image
  dropdownButton.addEventListener('click', function() {
    if (dropdownContent.style.display === 'none') {
      dropdownContent.style.display = 'block';
      dropdownContent.classList.add('show');
      dropdownContent.classList.remove('hide');
      dropdownIcon.src = 'dropdown2.png';
    } else {
      dropdownContent.style.display = 'none';
      dropdownContent.classList.add('hide');
      dropdownContent.classList.remove('show');
      dropdownIcon.src = 'dropdown.png';
    }
  });

   //save button functionality
   saveButton.addEventListener('click', function() {
    const title = titleInput.value;
    const note = noteTextArea.innerText;
    const image = noteTextArea.querySelector('img');
    if (title && note) {
      //store the note data in local storage
      const notes = JSON.parse(localStorage.getItem('notes')) || [];
      const noteData = { title, note };
      if (image) {
        const reader = new FileReader();
        reader.onload = function(event) {
          const base64Image = event.target.result;
          noteData.image = base64Image;
          notes.push(noteData);
          localStorage.setItem('notes', JSON.stringify(notes));
          console.log(`Note saved: ${title} - ${note}`);
          alert('Note saved successfully!');
        };
        reader.readAsDataURL(image);
      } else {
        notes.push(noteData);
        localStorage.setItem('notes', JSON.stringify(notes));
        console.log(`Note saved: ${title} - ${note}`);
        alert('Note saved successfully!');
      }
    } else {
      alert('Please enter a title and some text.');
    }
  });


  //delete button functionality
  trashButton.addEventListener('click', function() {
    noteContainer.remove();
    noteCount--;
  });



//image attach button functionality
const fileInput = document.createElement('input');
fileInput.type = 'file';
fileInput.accept = 'image/*';
fileInput.style.display = 'none'; // hide the file input

imgAttachButton.addEventListener('click', function() {
  fileInput.click(); // trigger the file input to open
});

// Add an event listener to the file input
fileInput.addEventListener('change', function(e) {
  // Get the selected file
  const selectedFile = e.target.files[0];
  const reader = new FileReader();
  
  // Read the file and attach it to the note
  reader.onload = function(event) {
    const imageData = event.target.result;
    const imageElement = document.createElement('img');
    imageElement.src = imageData;
    noteTextArea.appendChild(imageElement);
    imageElement.style.position = 'absolute';
    console.log('Image attached successfully!');
  };
  
  reader.readAsDataURL(selectedFile);
});
  

  noteContainer.appendChild(titleInput);
  noteContainer.appendChild(noteTextArea);
  noteContainer.appendChild(dropdownButton);
  noteContainer.appendChild(dropdownContent);

  document.querySelector('.note-containers').appendChild(noteContainer);
  noteCount++;
}
});